# Bluetooth-iOS
An iOS app using Bluetooth 4.0 technology
